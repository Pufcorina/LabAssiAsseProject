class Pub {
    /*@ spec_public */ public int x;  // illegal
}

