abstract class Thing {

  public abstract void mungle();

}
