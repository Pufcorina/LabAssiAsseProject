package other;
public class Other { static public String hello = "Hello"; }

