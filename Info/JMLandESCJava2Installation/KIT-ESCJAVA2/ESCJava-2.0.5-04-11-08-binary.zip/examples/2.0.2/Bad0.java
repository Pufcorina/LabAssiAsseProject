class Bad {

  /*@ ghost public /*@ non_null */ Object o; */ 
  
}
