class Bad {

  //@ requires a > 0;  /* multi-line "nested" 
                                comment */
  void m(int a) {}

}
